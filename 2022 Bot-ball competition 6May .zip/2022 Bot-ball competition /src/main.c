#include <kipr/wombat.h>

/* 
This progam of code will sucessfully gather all 5 of the rings and transport them onto the horizontal shaft, out of order. 
(FUNCTIONS_and_functionalities):

General Functions - functions that are used in WP functions
go_straight (dist, speed) (goes straight for dist in clicks at velocity speed)
backup(dist)  (goes backwards for a dist in clicks, dist must be a negative value)
turn_left (makes a 90 degree left turn) 
turn_right (makes a 90 degree right turn)
claw_ready (gets the arm up and claw open)
nudge_rings() (lowers arm and closes claw and moves forward to nudge rings on pvc)

WP Functions - functions for each WP
//SET 1 Move to Stack
pause (time) (pauses for time to allow create bot to get out of ET range)
et_d1(moves toward stack until given ET value)

//SET 2 Get Red, Orange, and Yellow Rings
get_red(once the desired ET distance is achieved, the arm will lower and the claw will grap the red ring)
place_r_bin (the arm will then raise toward the back of the bot and relase the red ring to the holder)
get_orange_yellow (the arm will lower back to the stack and retrieve the orange and yellow rings together)

//SET 3 Move to Horizontal PVC
backup_4turn(dist) (Using MAV the bot will back up enough to set up for the right turn dist in clicks needs to be negative) 
nineD_R(turns bot 90 degrees to the right using MAV)
go_til_pvc(while the the switch is open the MAV will drive until the switch hits the pvc) has argument for speed 
generate_align(the alignment code will achieve perfect alignment to the pvc using two switches until the bot hits both switches)
nineD_L(90 degree turn to the left)
drive_setup_ppvc(the bot will travel x distance past the horizontal pvc pipe)
one80_align(the bot will ensure the claw is in perfect alignment to smoothly place the ring)
// remove this -  one get_ring_placement(the claw will be alighted)

//SET 4 Place Rings on Horizontal PVC
placeOY_pvc(The bot will lower claw and drive straight so that orange and yellow rings are on the pvc then backup)
nudge_oy_ring(dist)(nudge the orange and yellow rings a distance dist so that it is slightly tilted upon release)
backup_after_OYplace(dist)(backup dist in clicks must be a negative number after the rings have been nudged) 
get_r_bin(gets the red ring from the bin)
placeR_pvc (places the red ring on the pvc and moves slightly forward before reseasing then backs up)
nudge_r_ring(dist) (nudge the red ring a distance dist so that it is slightly tilted upon release)
backup_after_Rplace(dist)(backup dist in clicks must be a negative number after the rings have been nudged) 

//SET 5 Move to Stack
R90_twdBL(Turn 90 degrees toward the black line)
get_to_BL(speed)(using MAV drive toward the black line at a speed velocity)
LnineD_twd_stk(once you are at the black line turn left 90 degrees toward the stack)
et_d2 (moves toward stack until given ET value)

//SET 6 Get Green and Blue Rings
get_green (once the desired ET distance is achieved, the arm will lower and the claw will grap the green ring)
place_g_bin (the arm will then raise toward the back of the bot and relase the green ring to the holder)
get_blue (the arm will lower back to the stack and retrieve the orange and yellow rings together)

//SET 7 Move to Horizontal PVC
backup4_return2pvc(dist) (Using MAV the bot will back up enough to set up for the right turn dist in clicks needs to be negative) 
L90_twdpvc(turn left 90 degrees toward the pvc)
head2_pvc(speed)(moves towards pvc until switch is bumped at speed velocity)
LnineD_alignpvc(ensure the left turn aligns the bot with the horizontal pvc )


//SET 8 Place Rings on Horizontal PVC
placeB_pvc (The bot will lower claw and drive straight so that blue ring is on the pvc)
nugde_ring (nudge the ring so that it is slightly tilted upon release)
backup_after_Bplace (backup to placing position)
placeG_pvc (The bot will lower claw and drive straight so that green ring is on the pvc) 
*/
//////////////////////////////////////////Function Prototypes////////////////////////////////////////////////////////////
//General Functions
void go_straight(int dist, int speed); 
void backup(int dist);  
void turn_left(); 
void turn_right(); 
void claw_ready();
void nudge_rings();


//WP Functions
//SET 1
void pause (int time);
void et_d1();

//SET 2
void get_red (); 
void place_r_bin (); 
void get_orange_yellow();

//SET 3
void backup_4turn(int dist);
void nineD_R();
void go_til_pvc(int speed);
void generate_align();
void nineD_L ();
void drive_setup_ppvc();
void one80_align();

//SET 4
void placeOY_pvc();
void nudge_oy_ring(int dist);
void backup_after_OYplace(int dist);
void get_r_bin();
void placeR_pvc();
void nudge_r_ring(int dist);
void backup_after_Rplace(int dist);

//SET 5
void R90_twdBL();
void get_to_BL(int speed);
void LnineD_twd_stk();
void et_d2();

//SET 6
void get_green();
void place_g_bin();
void get_blue();

//SET 7
void backup4_return2pvc(int dist);
void L90_twdpvc();
void head2_pvc(int speed);
void LnineD_alignpvc();

//SET 8
void placeB_pvc();
void nudge_b_ring();
void backup_after_Bplace();
void placeG_pvc();

///////////////////////////////////////////////////////////Constants///////////////////////////////////////////////////////////////////////////////
const int l_wheel= 2;       // port for left wheel 
const int r_wheel= 0;       // port for right wheel 
const int arm= 2;           // arm port 
const int claw= 0;			// claw port
const int ET = 5;			// ET sensor port
const int tophat= 4;		//tophat sensor port
const int black =  1400;	//threshold value for black line
const int f_switch = 9;		//front lever switch port
const int b_switch_l = 7;	//left back button switch port
const int b_switch_r = 8;   //right back button switch port

const int opened= 1583;                 // claw open enough for all rings 
const int closed= 2047;                 // claw totally closed 
const int arm_up=820;					//arm straight up

const int red_down= 1484;               // arm down to get red ring 
const int red_closed= 2047 ;            // claw closed to get red ring 
const int orange_down= 1612 ; 			// arm down to get orange ring 
const int orange_closed= 2047 ; 		// claw closed to get orange ring
const int yellow_down= 1708 ; 			// arm down to get yellow ring 
const int yellow_closed= 1990 ; 		// claw closed to get yellow ring
const int green_down= 1909 ; 			// arm down to get green ring 
const int green_closed= 2047 ; 			// claw closed to get green ring
const int blue_down= 2012 ; 			// arm down to get blue ring 
const int blue_closed= 1906 ; 			// claw closed to get blue ring

const int red_in_bin = 125;				//value of arm for putting red in the bin
const int green_in_bin = 97;				//value of arm for putting green in the bin
    

const int arm_down_nugde= 1541;          	// arm down so can nugde ring and not hit stand 
const int arm_up_with_ring= 1200;       // arm up once it has ring 

const int place_red= 1116 ; 			//arm value to place red on horizontal PVC
const int place_orange= 1090 ; 			//arm value to place orange on horizontal PVC
const int place_yellow= 925 ; 			//arm value to place yellow on horizontal PVC
const int place_green= 960 ; 			//arm value to place green on horizontal PVC
const int place_blue= 1019 ; 			//arm value to place blue on horizontal PVC

////////////////////////////////////////////////MAIN///////////////////////////////////////////////////////////////////////////
int main()
{
//add in competition light code start here
enable_servos();
	
//claw_ready();	
printf("SET 1: Get to Stack\n");
pause (1000); //argument: time - set the amount of time needed for create to get out of ET range
et_d1();

     /*
printf("SET 2: Get Rings\n");
get_red ();  
place_r_bin ();    
get_orange_yellow();

printf("SET 3: Get to Horizontal PVC\n");
backup_4turn(-1000); //argument: distance (must be negative) - check the distance needed to backup
nineD_R();
go_til_pvc(1000); //argument: speed - check speed for best performance getting to pvc. Max velocity 1500
generate_align();
nineD_L ();
drive_setup_ppvc();
one80_align();

printf("SET 4: Place Rings\n");
placeOY_pvc();
nudge_oy_ring(500); //argument: distance - check distance to push rings correct distance
backup_after_OYplace(-800);//argument: distance (must be negative) - check distance needed to backup
get_r_bin();
placeR_pvc();
nudge_r_ring(500); //argument: distance - check speed to push rings correct distance
backup_after_Rplace(-800); //argument: distance (must be negative) - check distance needed to backup

//SET 5
printf("SET 5: Get to Stack\n");
R90_twdBL();
get_to_BL(1000); //argument: speed - check speed for best performance getting to black line. Max speed 1500
LnineD_twd_stk();
et_d2();

//SET 6
printf("SET 6: Get Rings\n");
get_green();
place_g_bin();
get_blue();

//SET 7
printf("SET 7: Get to Horizontal PVC\n");
backup4_return2pvc(-1000); //argument: distance (must be negative) - check distance needed to backup
L90_twdpvc();
head2_pvc(1000); //argument: speed - check speed for best performance getting to black line. Max speed 1500
LnineD_alignpvc();

//SET 8
printf("SET 1: Place Rings\n");
placeB_pvc();
nudge_b_ring();
backup_after_Bplace();
placeG_pvc();

*/

return 0;	
}

////////////////////////////////////////////////Function Definitions//////////////////////////////////////////////////////////////////
//General Functions
void go_straight(int dist, int speed)
{

cmpc(r_wheel); //clear motor position counter on right wheel
while (gmpc(r_wheel)<dist)
	{
        mav(l_wheel,speed);
        mav(r_wheel,speed);
    }
	ao();
}

void backup(int dist)  //dist must be negative
{
	cmpc(l_wheel);//clear motor position counter on left wheel
    while(gmpc(l_wheel)>dist)
    {
        mav(l_wheel,-700);
        mav(r_wheel,-700);
    }
	ao();
}

void turn_left()
{
	cmpc(r_wheel);
	while(gmpc(r_wheel)<1150)
    {
		mav(l_wheel,-700);
		mav(r_wheel,700);
    }
ao();
}

void turn_right()
{
	cmpc(l_wheel);
	while(gmpc(l_wheel)<1150)
    {
		mav(l_wheel,700);
		mav(r_wheel,-700);
    }
ao();
}

void claw_ready()
{
    //put arm up
    set_servo_position(arm, arm_up);
    msleep(500);
    
    //open claw
    set_servo_position(claw, opened);
    msleep(500);
}

void nudge_rings()
{
}
/////////////////////////////////////////////////////WP Functions///////////////////////////////////////////////////////////
//SET 1
void pause (int time)
{
	msleep(time);
}

void et_d1()
{
	 go_straight(1350,500);
}

//SET 2
void get_red ()
{
    //start with arm up and claw open
    claw_ready();
    
    //get red ring
    set_servo_position(arm,red_down);
    msleep(500);
    
    //claw closed
    set_servo_position(claw, red_closed);
    msleep(500);
    
    //pick up ring arm up
    set_servo_position(arm,arm_up_with_ring);
    msleep(500); 
}

void place_r_bin ()
{
	 int dist_to_bin = arm_up_with_ring-red_in_bin;
    int stepper=30;
    int step=dist_to_bin/stepper;
    int counter=1;
    int back_position= arm_up_with_ring;
    while (counter<stepper)
    {
    back_position=back_position-step;
    set_servo_position(arm, back_position);
    msleep(100);
    
    printf("back position: %d\n",back_position);
        counter=counter+1;
    }
    set_servo_position(arm,red_in_bin);
    msleep(500);
    set_servo_position(claw,opened);
    msleep(500);
}

void get_orange_yellow()
{
	claw_ready();
	
    //get orange ring
    set_servo_position(arm,orange_down);
    msleep(500);
    
    //claw closed
    set_servo_position(claw,orange_closed);
    msleep(500);
    
    //pick up ring arm up
    set_servo_position(arm,arm_up_with_ring);
    msleep(500);
}


//SET 3
void backup_4turn(int dist)
{
	backup(dist);
}
void nineD_R()
{
	turn_right();
}
void go_til_pvc(int speed)
{
	while(digital(f_switch)==00)
    {
        mav(l_wheel,speed);
        mav(r_wheel,speed);
    }
    ao();
}
void generate_align()
{
	printf("generate_align\n");
}
void nineD_L ()
{
	turn_left();
}
void drive_setup_ppvc()
{
	printf("drive_setup\n");
}
void one80_align()
{
	printf("one80_align\n");
}

//SET 4
void placeOY_pvc()
{
	printf("placeOY_pvc\n");
}
void nudge_oy_ring(int dist)
{
	printf("nudge_oy_ring\n");
}
void backup_after_OYplace(int dist)
{
	backup(dist);
}
void get_r_bin()
{
	printf("get_r_bin\n");
}
void placeR_pvc()
{
	printf("placeR_pvc\n");
}
void nudge_r_ring(int dist)
{
	printf("nudge_r_ring()\n");
}
void backup_after_Rplace(int dist)
{
	backup(dist);
}

//SET 5
void R90_twdBL()
{
	turn_right();
}
void get_to_BL(int speed)
{
// go until you hit black line 
	while (analog(ET)<black)
    { 
		mav (l_wheel, speed);
		mav (r_wheel,speed);
            
    }
	ao();
}

void LnineD_twd_stk()
{
	turn_left();
}
void et_d2()
{
	printf("et_d2\n");
}

//SET 6
void get_green()
{
	printf("get_green\n");
}
void place_g_bin()
{
	printf("place_g_bin\n");
}
void get_blue()
{
	printf("get_blue\n");
}

//SET 7
void backup4_return2pvc(int dist)
{
	backup(dist);
}
void L90_twdpvc()
{
	turn_left();
}
void head2_pvc(int speed)
{
	while(digital(f_switch)==00)
    {
        mav(l_wheel,speed);
        mav(r_wheel,speed);
    }
    ao();
}
void LnineD_alignpvc()
{
	turn_left();
}
    
//Set 8
void placeB_pvc()
{
}
void nudge_b_ring()
{
}
void backup_after_Bplace()
{
}
void placeG_pvc()
{
}
