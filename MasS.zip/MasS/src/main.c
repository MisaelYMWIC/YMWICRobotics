#include <kipr/botball.h>
#include "MasS.h"
int main()
{
  movearm(1800);
  return 0;
}

