#include <kipr/botball.h>

void movearm(int distance);//int distance for the amount of ticks you want to move
